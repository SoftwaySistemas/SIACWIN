﻿
***** ATENÇÃO:

Para compatibilizar os namespaces instalar o XSD em um só pacote chamado: nfse

Necessário para um ambiente uniforme incluindo ABRASF 203 e ADN Nota Nacional.

TINUS203.